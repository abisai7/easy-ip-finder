(function(){const o=document.createElement("link").relList;if(o&&o.supports&&o.supports("modulepreload"))return;for(const t of document.querySelectorAll('link[rel="modulepreload"]'))n(t);new MutationObserver(t=>{for(const s of t)if(s.type==="childList")for(const c of s.addedNodes)c.tagName==="LINK"&&c.rel==="modulepreload"&&n(c)}).observe(document,{childList:!0,subtree:!0});function r(t){const s={};return t.integrity&&(s.integrity=t.integrity),t.referrerPolicy&&(s.referrerPolicy=t.referrerPolicy),t.crossOrigin==="use-credentials"?s.credentials="include":t.crossOrigin==="anonymous"?s.credentials="omit":s.credentials="same-origin",s}function n(t){if(t.ep)return;t.ep=!0;const s=r(t);fetch(t.href,s)}})();const i={getVersionUrl:e=>e===6?"https://api64.ipify.org?format=json":"https://api.ipify.org?format=json",fetchIP:async e=>{try{const o=await fetch(e);if(!o.ok)throw new Error("Failed to fetch IP");const r=await o.json();if(!r.ip)throw new Error("Invalid response data");return r.ip}catch(o){throw new Error(`Error fetching IP: ${o.message}`)}},copyToClipboard:async(e,o=null)=>{if(e)try{await navigator.clipboard.writeText(e),o&&o()}catch(r){console.error("Error copying IP to clipboard:",r)}},init:async(e=4,o=!1,r=null)=>{try{const n=i.getVersionUrl(e),t=await i.fetchIP(n);return o&&await i.copyToClipboard(t,r),{ip:t,error:""}}catch(n){return console.error("Initialization error:",n),{ip:null,error:n.message}}}};let d=null;const g=`
<svg xmlns="http://www.w3.org/2000/svg" width="40" height="40" viewBox="0 0 16 16">
  <path fill="none" d="M12 2a2 2 0 012 2v8a2 2 0 01-2 2H4a2 2 0 01-2-2V4a2 2 0 012-2zm-2 3H8v6h1V9.014h1c.298-.013 2 0 2-2.018 0-1.74-1.314-1.952-1.825-1.987zM6 5H5v6h1zm4 .984c.667 0 1 .336 1 1.008C11 7.664 10.667 8 10 8H9V5.984z"/>
</svg>`,u=`
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 36 36">
  <path fill="currentColor" d="M22.6 4h-1.05a3.89 3.89 0 00-7.31 0h-.84A2.41 2.41 0 0011 6.4V10h14V6.4A2.41 2.41 0 0022.6 4m.4 4H13V6.25a.25.25 0 01.25-.25h2.69l.12-1.11a1.24 1.24 0 01.55-.89 2 2 0 013.15 1.18l.09.84h2.9a.25.25 0 01.25.25z"/>
  <path fill="currentColor" d="M33.25 18.06H21.33l2.84-2.83a1 1 0 10-1.42-1.42l-5.25 5.25 5.25 5.25a1 1 0 00.71.29 1 1 0 00.71-1.7l-2.84-2.84h11.92a1 1 0 000-2"/>
  <path fill="currentColor" d="M29 16h2V6.68A1.66 1.66 0 0029.35 5h-2.27v2H29z"/>
  <path fill="currentColor" d="M29 31H7V7h2V5H6.64A1.66 1.66 0 005 6.67v24.65A1.66 1.66 0 006.65 33h22.71A1.66 1.66 0 0031 31.33v-9.27h-2z"/>
  <path fill="none" d="M0 0h36v36H0z"/>
</svg>`,f=chrome.i18n.getMessage("extName"),l=chrome.i18n.getMessage("copyToClipboardAction"),m=chrome.i18n.getMessage("copyConfigText"),v=chrome.i18n.getMessage("genericErrorMessage");chrome.i18n.getMessage("changeVersionToShowText");const y=chrome.i18n.getMessage("rateUsMessage"),w=chrome.i18n.getMessage("authorMessage"),b=`
<section class="top-section">
  <div class="logo">   
    ${g}
    <h1>${f}</h1>
  </div>
  <button class="change-version-btn" title="${l}">
    <svg xmlns="http://www.w3.org/2000/svg" width="1em" height="1em" viewBox="0 0 48 48">
      <path fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="4" d="M42 19H6M30 7l12 12M6.799 29h36m-36 0l12 12"/>
    </svg> 
    <span class="change-version-btn-text"></span>
  </button>
</section>

<section class="ip-container">
  <div class="lds-loading">
    <div></div>
    <div></div>
    <div></div>
  </div>
  <h1>
    <x-ip class="hide"></x-ip>
  </h1>
  <button class="copy-to-clipboard-btn hide" title="${l}">
    ${u}
  </button>
  <div class="error hide"></div>
</section>

<section class="config-section">
  <div class="clipboard-config">
    <input class="toggle-input" type="checkbox" id="clipboard-config-check" />
    <label for="clipboard-config-check" class="toggle-button"><span>${m}</span></label>
  </div>
</section>
<section class="author-section">
  <p>${y}</p>
  <p>${w}</p>
</section>
`;document.querySelector("#app").innerHTML=b;function C(e){chrome.storage.sync.set({copyToClipboardOnLoad:e})}function M(e){chrome.storage.sync.set({versionConfig:e})}document.querySelector("#clipboard-config-check").addEventListener("change",async e=>{C(e.target.checked)});const p=async(e=4)=>{a(!0);const o=await chrome.storage.sync.get(["copyToClipboardOnLoad"]);document.querySelector("#clipboard-config-check").checked=o.copyToClipboardOnLoad;const r=await i.init(e,o.copyToClipboardOnLoad,h);if(r.ip==null)return a(!1),T(`${v} ${r.error}`);d=r.ip;let n=await chrome.storage.sync.get(["versionConfig"]);x(r.ip),document.querySelector(".change-version-btn-text").innerText=chrome.i18n.getMessage("changeVersionToShowText").replace("{v}",n.versionConfig===4?6:4),a(!1),L()},L=()=>{const e=document.querySelector(".copy-to-clipboard-btn");e.classList.remove("hide"),e.classList.add("show")},a=(e=!0)=>{const o=document.querySelector(".lds-loading");e?(o.classList.remove("hide"),o.classList.add("show")):(o.classList.remove("show"),o.classList.add("hide"))},T=e=>{const o=document.querySelector(".error");o.innerHTML=`${e}`,o.classList.remove("hide")},x=e=>{const o=document.querySelector("x-ip");o.innerText=e,o.classList.remove("hide"),o.classList.add("show")},V=()=>{const e=document.querySelector("x-ip");e.classList.remove("show"),e.classList.add("hide")},h=()=>{const e={type:"basic",title:chrome.i18n.getMessage("extName"),message:chrome.i18n.getMessage("ipCopiedText"),iconUrl:"/icon128.png",silent:!0};chrome.notifications.create(e)};document.querySelector(".change-version-btn").addEventListener("click",async()=>{V();let o=(await chrome.storage.sync.get(["versionConfig"])).versionConfig===4?6:4;M(o),p(o)});document.querySelector(".copy-to-clipboard-btn").addEventListener("click",()=>{i.copyToClipboard(d,h)});document.addEventListener("DOMContentLoaded",async()=>{const e=await chrome.storage.sync.get(["versionConfig"]),o=e.versionConfig?e.versionConfig:4;p(o)});
